



<?php $__env->startSection('title', 'Index'); ?>


<div>

    <a class="add-course-button" href="<?php echo e(route('courses.create')); ?>">Add New Course</a>

    <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <ul>
        <li> <?php echo e($course->title); ?> </li>
        <li> <?php echo e($course->description); ?> </li>
        <li> <?php echo e($course->language); ?> </li>
        <li> <?php echo e($course->difficulty); ?> </li>
        <li> <?php echo e($course->instructor); ?> </li>
        <li> <?php echo e($course->email); ?> </li>
    </ul>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
    <td class="actions-cell">

        <a class="view-course-button" href="<?php echo e(route('courses.show', $course->id)); ?>">View Course</a>

        <a class="edit-course-button" href="<?php echo e(route('courses.edit', $course->id)); ?>">Edit Course</a>

        <form class="destroy-form" action="<?php echo e(route('courses.destroy', $course->id)); ?>">
            <?php echo method_field('DELETE'); ?>
            <?php echo csrf_field(); ?>
            <button type="Submit" class="destroy-button">Delete</button>
        </form>
    </td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/styles.css')); ?>">
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CRUD\resources\views/courses/index.blade.php ENDPATH**/ ?>