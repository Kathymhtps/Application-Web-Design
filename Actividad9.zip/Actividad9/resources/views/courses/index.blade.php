{{-- What layout is gonna use --}}
@extends('layouts.plantilla')

{{-- Just for one line --}}
@section('title', 'Index')

{{-- More than one line --}}
<div>

    <a class="add-course-button" href="{{ route('courses.create') }}">Add New Course</a>

    @foreach ($courses as $course)
    <ul>
        <li> {{ $course->title }} </li>
        <li> {{ $course->description }} </li>
        <li> {{ $course->language }} </li>
        <li> {{ $course->difficulty }} </li>
        <li> {{ $course->instructor }} </li>
        <li> {{ $course->email }} </li>
    </ul>
    @endforeach
</div>