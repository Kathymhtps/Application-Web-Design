

<?php $__env->startSection('content'); ?>

    <h2> Course Details</h2>
    <div class="course-details">
        <h3><?php echo e($course->title); ?></h3>
        <p><strong>Description: </strong><?php echo e($course->description); ?></p>
        <p><strong>Language: </strong><?php echo e($course->language); ?></p>
        <p><strong>Difficulty: </strong><?php echo e($course->difficulty); ?></p>
        <p><strong>Instructor: </strong><?php echo e($course->instructor); ?></p>
        <p><strong>Email: </strong><?php echo e($course->email); ?></p>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CRUD\resources\views/courses/show.blade.php ENDPATH**/ ?>