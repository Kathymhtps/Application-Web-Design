

<?php $__env->startSection('content'); ?>

<h2>Edit Course</h2>

<form action="<?php echo e(route('courses.update', $course->id)); ?>" method="post" class="edit-course-form">
    <?php echo csrf_field(); ?>

    <?php echo method_field('PUT'); ?>

    <label>Title:</label>
    <input type="text" name="title" value="<?php echo e($course->title); ?>">

    <label>Description:</label>
    <textarea name="description"><?php echo e($course->description); ?>"</textarea>

    <label>Language:</label>
    <input type="text" name="language" value="<?php echo e($course->language); ?>">
    
    <label>Difficulty:</label>
    <select name="difficulty">
        <option value="Beginner" <?php echo e($course->difficulty == 'Beginner' ? 'selected' : ''); ?>>Beginner</option>
        <option value="Intermediate" <?php echo e($course->difficulty == 'Intermediate' ? 'selected' : ''); ?>>Intermediate</option>
        <option value="Advanced" <?php echo e($course->difficulty == 'Advanced' ? 'selected' : ''); ?>>Advanced</option>
    </select>

    <label>Intructor:</label>
    <input type="text" name="instructor" value="<?php echo e($course->instructor); ?>">

    <label>Email:</label>
    <input type="text" name="email" value="<?php echo e($course->email); ?>">

    <button type="submit">Actualizar</button>

</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CRUD\resources\views/courses/edit.blade.php ENDPATH**/ ?>