



<?php $__env->startSection('title', 'Create'); ?>

<h2>Add New Course</h2>

<form class="course-form" action="<?php echo e(route('courses.store')); ?>" method="post">

    <?php echo csrf_field(); ?>

    <label for="title">Title</label>
    <input type="text" id="title" name="title">

    <label for="description">Description</label>
    <textarea id="description" name="description"></textarea>

    <label for="language">Language</label>
    <input type="text" id="language" name="language">

    <label for="difficulty">Difficulty</label>
    <select name="difficulty" id="difficulty">
        <option value="Beginner">Beginner</option>
        <option value="Intermediate">Intermediate</option>
        <option value="Advanced">Advanced</option>
    </select>

    <label for="instructor">Instructor</label>
    <input type="text" id="instructor" name="instructor">

    <label for="email">Email</label>
    <input type="email" id="email" name="email">

    <input type="submit" value="Add Course">
</form>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Evidencia2\resources\views/courses/create.blade.php ENDPATH**/ ?>