



<?php $__env->startSection('title', 'Index'); ?>


<div>

    <a class="add-course-button" href="<?php echo e(route('courses.create')); ?>">Add New Course</a>

    <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <ul>
        <li> <?php echo e($course->title); ?> </li>
        <li> <?php echo e($course->description); ?> </li>
        <li> <?php echo e($course->language); ?> </li>
        <li> <?php echo e($course->difficulty); ?> </li>
        <li> <?php echo e($course->instructor); ?> </li>
        <li> <?php echo e($course->email); ?> </li>
    </ul>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Actividad9\resources\views/courses/index.blade.php ENDPATH**/ ?>